// app/javascript/bravura_template_prime/application.js
console.log('BravuraTemplatePrime JavaScript loaded')

// You can start adding your JavaScript code here;
